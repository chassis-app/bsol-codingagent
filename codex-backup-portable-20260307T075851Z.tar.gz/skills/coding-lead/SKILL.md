---
name: coding-lead
description: Orchestrate end-to-end multi-agent software delivery with architect planning, parallel QA and programming, mandatory triad code-review gates, full test execution, and roadmap closeout.
---

# Coding Lead

## When To Use

Use this skill when the user asks for a coordinated coding workflow across architect, programmers, QA, reviewers, and roadmap/task governance.

## Core Constraints

- Treat the workflow as gate-based delivery.
- Keep parallel work explicit with a dependency DAG.
- Use `$code-reviewer` for every review gate.
- Do not skip any required reviewer in `$code-reviewer` unless the user explicitly says so.
- Block progression when a gate fails.
- Run architect clarification as a file-based human-in-the-loop cycle in `docs/plan/<task>.md`.
- When architect asks any critical question, stop immediately with `PENDING_HUMAN_INPUT` and wait for the human reply before running any later gate.
- Never answer architect clarification questions on behalf of the human in `Human Responses`.

## Human Loop Enforcement (Non-Negotiable)

- Clarification gate is blocking until human responses exist for all critical architect questions.
- If `Questions for Human` is non-empty and `Human Responses` is missing/incomplete:
  - Update `docs/plan/<task>.md` with current architect questions.
  - Set `Clarification Status` to `PENDING_HUMAN_INPUT`.
  - Return control to user immediately; do not run Step 2+ work in the same turn.
- Allowed: provide optional suggested answers to help the user decide.
  - Put suggestions in assistant chat only under `Suggested Responses (Optional)`.
  - Do not write suggestions into `Human Responses`.
- Forbidden while pending human input:
  - Running `$qa-writer`, `$code-reviewer`, `$qa-runner`, or implementation work.
  - Marking clarification as complete.
  - Filling `Human Responses` yourself.

## Clarification Status Values

- `PENDING_HUMAN_INPUT`: architect questions awaiting user answers; workflow is blocked.
- `IN_REVIEW_WITH_ARCHITECT`: user answers provided; routing back to architect for synthesis.
- `COMPLETE`: no critical unanswered questions remain; Step 2 may start.

## Required Workflow

1. Clarify and plan with Architect.
   - Route to `$opencode-glm-architect` for requirement analysis.
   - Use a task plan file at `docs/plan/<task>.md` for all architect questions and human answers.
   - If the file does not exist, create it with sections:
     - `Context`
     - `Questions for Human`
     - `Human Responses`
     - `Architect Synthesis`
     - `Assumptions`
     - `Open Questions`
     - `Clarification Status`
   - Architect writes all clarification questions into `Questions for Human`.
   - Pause workflow with status `PENDING_HUMAN_INPUT` until the human adds answers under `Human Responses`.
   - The moment `PENDING_HUMAN_INPUT` is set, stop this turn and ask the user to answer in `Human Responses` (or directly in chat for later transcription).
   - Resume by re-reading the same file, routing responses back to Architect, and updating `Architect Synthesis`, `Assumptions`, and `Open Questions`.
   - Set status to `IN_REVIEW_WITH_ARCHITECT` while architect is synthesizing human responses.
   - Repeat this write/pause/read loop until all critical uncertainties are resolved or explicitly logged as assumptions.
   - Only then set `Clarification Status` to `COMPLETE` and continue to Step 2.
   - Produce:
     - `docs/plan/<task>.md` clarification record with resolved Q&A history
     - assumptions and open-questions log
     - requirement breakdown with acceptance criteria
     - business logic and technical spec per task
     - dependency DAG showing what can run in parallel

2. Unit-test planning and additions.
   - Route parallel work to `$qa-writer` by task cluster.
   - Add/update unit tests before implementation starts.
   - Output test mapping from requirements to test cases.

3. Mandatory test-review gate.
   - Route to `$code-reviewer`.
   - Follow `$code-reviewer` execution rules exactly, including out-of-sandbox approval flow and mandatory triad execution.
   - Require severity-first findings synthesis.
   - Block if any triad reviewer run fails or blocking findings remain.

4. Parallel implementation.
   - Assign tasks to multiple programmers based on DAG and ownership.
   - Enforce requirement IDs and acceptance criteria in each implementation handoff.

5. Mandatory code-review gate.
   - Route to `$code-reviewer` again over the full code delta.
   - Keep all triad reviewers mandatory.
   - Block until blocking issues are resolved.

6. Unit/regression execution gate.
   - Route to `$qa-runner` (parallel where possible).
   - Run full unit tests and required regression suites.
   - Block on failures.

7. Integration/e2e expansion.
   - Route to `$qa-writer` for integration/e2e additions where cross-component behavior changed.
   - Avoid unnecessary e2e additions when no cross-component behavior changed.

8. Integration/e2e execution gate.
   - Route to `$qa-runner` to execute integration/e2e suites.
   - Block on failures.

9. Closeout.
   - Coding Lead reviews task board and `ROADMAP.md`.
   - Update delivered scope, decisions, residual risks, and follow-up items.

## Gate Output Format

For each gate, return:

- `Gate`: name
- `Status`: pass/block (`PENDING_HUMAN_INPUT` must be reported as `block`)
- `Blocking issues`: severity-first list
- `Artifacts`: links/paths to outputs
- `Next actions`: exact owners and task IDs

## Required Pending-Input Response

When clarification is blocked on human input, end the turn with this exact gate framing and do nothing else after it:

- `Gate`: Clarify and plan with Architect
- `Status`: block (`PENDING_HUMAN_INPUT`)
- `Blocking issues`: unanswered architect questions (list question IDs)
- `Artifacts`: `docs/plan/<task>.md`
- `Next actions`: `Human` answers questions under `Human Responses`; `Coding Lead` resumes architect synthesis afterward

## Coordination Rules

- Keep one owner per task; many contributors are allowed, but ownership must be unambiguous.
- Prefer parallel execution for independent DAG branches.
- Timebox analysis to avoid paralysis; capture assumptions explicitly when unresolved details are non-critical.
- Never present a gate as passed if one required tool/reviewer failed to run.
