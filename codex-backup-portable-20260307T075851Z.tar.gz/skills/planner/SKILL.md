---
name: planner
description: Turn a user-provided task description into a roadmap-ready plan by asking clarification questions, then updating ROADMAP.md backlog, milestones, reminder block, and decision log.
---

# Planner

## When To Use

Use this skill when the user asks to plan work and add or update tasks in `ROADMAP.md`.

## Core Behavior

- Start from the user's task description.
- Ask clarification questions first.
- Convert answers into an implementation-ready roadmap item.
- Update `ROADMAP.md` in the same change set.

## Required Clarification Flow

Before editing `ROADMAP.md`, ask concise questions to remove critical ambiguity.
Prioritize these fields:

1. outcome and definition of done
2. scope boundaries (in-scope vs out-of-scope)
3. target date (exact `YYYY-MM-DD`)
4. priority (`low`, `medium`, `high`, `immediate`)
5. dependencies and risks
6. owner (default `planner` if not specified)

Rules:

- Ask only what is required to place the task correctly.
- If non-critical details are unknown, record explicit assumptions and continue.
- If target date is missing, ask for it (date is mandatory in this repo).

## ROADMAP.md Update Contract

Follow repository roadmap rules exactly.

When adding a new task:

1. Add one row in `Planning Backlog Management` with all required fields:
   - `ID`
   - `Task Title`
   - `Task Description`
   - `Action Points` (HTML `<br>` line breaks between bullets)
   - `Horizon` (`short`, `medium`, `long`)
   - `Priority` (`low`, `medium`, `high`, `immediate`)
   - `Sequence` (explicit integer order)
   - `Status` (default `planned`)
   - `Target Date` (exact `YYYY-MM-DD`)
   - `Dependencies`
   - `Owner`
2. Keep `Sequence` values consistent and unique after insertion.
3. If the new task affects milestone planning, add or update `Milestones And Timeline` rows.
4. Update `Coming Soon Reminder Block (Planner Startup)` so next 30/60/90 days reflect current roadmap data.
5. Add a `Technical Decision Log` row when introducing planning/process/scope decisions.

When updating an existing task:

- Modify task row fields directly.
- Reconcile dependencies, sequence, milestones, and reminder block accordingly.
- Add decision log entry if priority/scope/sequence strategy changed.

## Planning Quality Standard

For each planned task, ensure:

- title is specific and outcome-oriented
- description is handoff-ready
- action points are executable and testable
- dependencies are explicit
- sequencing is realistic with adjacent items
- milestone impact is reflected when relevant

## Response Format

After updating roadmap, return:

- `Clarifications captured`: key answered questions
- `Assumptions made`: only unresolved non-critical items
- `Roadmap edits`: exact sections changed
- `Inserted/Updated task`: ID, title, sequence, target date, dependencies
- `Milestone/reminder updates`: summary

## Safety Rules

- Do not leave roadmap partially updated.
- Do not use non-date targets like "Q2" or month-only values.
- Do not skip sequence/dependency reconciliation.
- Do not skip reminder block refresh after roadmap changes.
