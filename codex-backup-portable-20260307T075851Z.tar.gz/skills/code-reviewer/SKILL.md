---
name: code-reviewer
description: Run mandatory multi-model code reviews using OpenCode zai-coding-plan/glm-5, OpenCode kimi-for-coding/k2p5, and Claude Code in parallel, then synthesize findings with severity-first reporting.
---

# Code Reviewer

## Overview

Use this skill when the user asks for a code review.
This skill always initiates review with this exact combination:

- OpenCode with `zai-coding-plan/glm-5`
- OpenCode with `kimi-for-coding/k2p5`
- Claude Code

Do not skip any reviewer unless the user explicitly asks to.

## Execution Mode

1. Ask upfront for out-of-sandbox execution approval:
   - `Do you want me to run this code review out of sandbox now?`
2. If approved, run out of sandbox directly.
3. Do not run a sandbox attempt first for review commands.
4. If setup still fails out of sandbox, ask the user to fix their local environment/tools.

## Workflow

1. Gather the user review prompt (or file/PR context).
2. Run the triad launcher:
   - `bash scripts/run_code_review_triad.sh "<review prompt>"`
3. The launcher runs all 3 reviewers in parallel as separate workers and prints each raw command/response block.
4. The launcher prints a concatenated `FULL REVIEW LIST` summary across all 3 reviewers.
5. Provide a severity-ordered review summary (bugs, regressions, risk, missing tests first).

## Scripts

- `scripts/run_code_review_triad.sh`
  - Runs all 3 required reviewers in parallel
  - Prints raw command + raw output blocks for each reviewer
  - Prints a concatenated `FULL REVIEW LIST`
  - Returns non-zero if any reviewer fails

## Model/Tool Overrides

Environment variables:

- `OPENCODE_BIN` (default: `opencode`)
- `OPENCODE_GLM_MODEL` (default: `zai-coding-plan/glm-5`)
- `OPENCODE_KIMI_MODEL` (default: `kimi-for-coding/k2p5`)
- `OPENCODE_KIMI_FALLBACK_MODELS` (optional, comma-separated)
- `OPENCODE_REVIEW_AGENT` (optional)
- `CLAUDE_CODE_BIN` (default: `~/.local/bin/claude` when present, otherwise `claude`)
