#!/usr/bin/env bash
set -u

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" || "$#" -eq 0 ]]; then
  cat <<'USAGE'
Usage:
  run_code_review_triad.sh "<review prompt>"

Runs mandatory code-review triad in parallel:
  1) OpenCode (GLM)
  2) OpenCode (Kimi)
  3) Claude Code

Environment:
  OPENCODE_BIN                  OpenCode CLI binary (default: opencode)
  OPENCODE_GLM_MODEL            OpenCode GLM model ref (default: zai-coding-plan/glm-5)
  OPENCODE_KIMI_MODEL           OpenCode Kimi model ref (default: kimi-for-coding/k2p5)
  OPENCODE_KIMI_FALLBACK_MODELS Comma-separated fallback models for Kimi (optional)
  OPENCODE_REVIEW_AGENT         Optional OpenCode agent name
  CLAUDE_CODE_BIN               Claude CLI binary
                                (default: ~/.local/bin/claude when present, otherwise claude)
USAGE
  exit 0
fi

prompt="$*"
opencode_bin="${OPENCODE_BIN:-opencode}"
glm_model="${OPENCODE_GLM_MODEL:-zai-coding-plan/glm-5}"
kimi_model="${OPENCODE_KIMI_MODEL:-kimi-for-coding/k2p5}"
review_agent="${OPENCODE_REVIEW_AGENT:-}"

if [[ -n "${CLAUDE_CODE_BIN:-}" ]]; then
  claude_bin="${CLAUDE_CODE_BIN}"
elif [[ -x "${HOME}/.local/bin/claude" ]]; then
  claude_bin="${HOME}/.local/bin/claude"
else
  claude_bin="claude"
fi

tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT

status_glm=0
status_kimi=0
status_claude=0

glm_cmd_file="$tmp_dir/glm.cmd"
glm_out_file="$tmp_dir/glm.out"
glm_status_file="$tmp_dir/glm.status"

kimi_cmd_file="$tmp_dir/kimi.cmd"
kimi_out_file="$tmp_dir/kimi.out"
kimi_status_file="$tmp_dir/kimi.status"

claude_cmd_file="$tmp_dir/claude.cmd"
claude_out_file="$tmp_dir/claude.out"
claude_status_file="$tmp_dir/claude.status"

format_cmd() {
  local out=""
  local token
  for token in "$@"; do
    out+="$(printf '%q ' "$token")"
  done
  printf '%s' "${out% }"
}

require_executable() {
  local label="$1"
  local bin="$2"

  if [[ "$bin" == */* ]]; then
    [[ -x "$bin" ]]
    return
  fi

  command -v "$bin" >/dev/null 2>&1
}

is_model_not_found_error() {
  local output="$1"
  [[ "$output" == *"Model not found"* || "$output" == *"ProviderModelNotFoundError"* || "$output" == *"ModelNotFoundError"* ]]
}

trim_ws() {
  local value="$1"
  value="${value#"${value%%[![:space:]]*}"}"
  value="${value%"${value##*[![:space:]]}"}"
  printf '%s' "$value"
}

add_unique_model() {
  local candidate="$1"
  local existing

  [[ -n "$candidate" ]] || return 0
  if [[ "$candidate" == "$kimi_model" ]]; then
    return 0
  fi
  for existing in "${kimi_fallbacks[@]}"; do
    if [[ "$existing" == "$candidate" ]]; then
      return 0
    fi
  done
  kimi_fallbacks+=("$candidate")
}

preflight_failed=0
if ! require_executable "OpenCode" "$opencode_bin"; then
  echo "ERROR: OpenCode executable not found: ${opencode_bin}" >&2
  preflight_failed=1
fi
if ! require_executable "Claude Code" "$claude_bin"; then
  echo "ERROR: Claude Code executable not found: ${claude_bin}" >&2
  preflight_failed=1
fi

if [[ $preflight_failed -ne 0 ]]; then
  echo
  echo "Preflight failed. Configure OPENCODE_BIN and/or CLAUDE_CODE_BIN, then retry." >&2
  exit 1
fi

run_glm_reviewer() {
  local cmd=("$opencode_bin" run --model "$glm_model")
  local output
  local status

  if [[ -n "$review_agent" ]]; then
    cmd+=(--agent "$review_agent")
  fi
  cmd+=("$prompt")

  printf '%s\n' "$(format_cmd "${cmd[@]}")" > "$glm_cmd_file"
  output="$("${cmd[@]}" 2>&1)"
  status=$?
  printf '%s\n' "$output" > "$glm_out_file"
  printf '%s\n' "$status" > "$glm_status_file"
}

run_kimi_reviewer() {
  local attempts=()
  local cmd=("$opencode_bin" run --model "$kimi_model")
  local output
  local status
  local attempted_model="$kimi_model"

  if [[ -n "$review_agent" ]]; then
    cmd+=(--agent "$review_agent")
  fi
  cmd+=("$prompt")

  attempts+=("PRIMARY|$attempted_model|$(format_cmd "${cmd[@]}")")
  output="$("${cmd[@]}" 2>&1)"
  status=$?

  local combined_output="===== ATTEMPT PRIMARY (${attempted_model}) =====\n${output}\n"
  local combined_cmds="$(format_cmd "${cmd[@]}")"

  kimi_fallbacks=()
  add_unique_model "kimi-for-coding/k2p5"
  if [[ -n "${OPENCODE_KIMI_FALLBACK_MODELS:-}" ]]; then
    IFS=',' read -r -a extra_kimi_models <<< "${OPENCODE_KIMI_FALLBACK_MODELS}"
    for model in "${extra_kimi_models[@]}"; do
      add_unique_model "$(trim_ws "$model")"
    done
  fi

  if [[ $status -ne 0 ]] && is_model_not_found_error "$output" && [[ ${#kimi_fallbacks[@]} -gt 0 ]]; then
    local fallback_model
    for fallback_model in "${kimi_fallbacks[@]}"; do
      cmd=("$opencode_bin" run --model "$fallback_model")
      if [[ -n "$review_agent" ]]; then
        cmd+=(--agent "$review_agent")
      fi
      cmd+=("$prompt")

      output="$("${cmd[@]}" 2>&1)"
      status=$?

      combined_cmds+=$'\n'
      combined_cmds+="$(format_cmd "${cmd[@]}")"
      combined_output+="===== ATTEMPT FALLBACK (${fallback_model}) =====\n${output}\n"

      if [[ $status -eq 0 ]]; then
        break
      fi
    done
  fi

  printf '%s\n' "$combined_cmds" > "$kimi_cmd_file"
  printf '%b\n' "$combined_output" > "$kimi_out_file"
  printf '%s\n' "$status" > "$kimi_status_file"
}

run_claude_reviewer() {
  local cmd=("$claude_bin" -p "$prompt")
  local output
  local status

  printf '%s\n' "$(format_cmd "${cmd[@]}")" > "$claude_cmd_file"
  output="$("${cmd[@]}" 2>&1)"
  status=$?
  printf '%s\n' "$output" > "$claude_out_file"
  printf '%s\n' "$status" > "$claude_status_file"
}

run_glm_reviewer & pid_glm=$!
run_kimi_reviewer & pid_kimi=$!
run_claude_reviewer & pid_claude=$!

wait "$pid_glm"
wait "$pid_kimi"
wait "$pid_claude"

status_glm="$(cat "$glm_status_file")"
status_kimi="$(cat "$kimi_status_file")"
status_claude="$(cat "$claude_status_file")"

emit_block() {
  local label="$1"
  local cmd_file="$2"
  local out_file="$3"

  echo "===== ${label} COMMAND ====="
  cat "$cmd_file"
  echo "===== ${label} RESPONSE ====="
  cat "$out_file"
  echo
}

emit_block "OPENCODE_GLM5" "$glm_cmd_file" "$glm_out_file"
emit_block "OPENCODE_KIMI25" "$kimi_cmd_file" "$kimi_out_file"
emit_block "CLAUDE_CODE" "$claude_cmd_file" "$claude_out_file"

echo "===== FULL REVIEW LIST ====="
echo "1. OPENCODE_GLM5 (status=${status_glm})"
echo "2. OPENCODE_KIMI25 (status=${status_kimi})"
echo "3. CLAUDE_CODE (status=${status_claude})"
echo

echo "===== EXIT STATUS ====="
echo "OPENCODE_GLM5=${status_glm}"
echo "OPENCODE_KIMI25=${status_kimi}"
echo "CLAUDE_CODE=${status_claude}"

if [[ $status_glm -ne 0 || $status_kimi -ne 0 || $status_claude -ne 0 ]]; then
  exit 1
fi

exit 0
