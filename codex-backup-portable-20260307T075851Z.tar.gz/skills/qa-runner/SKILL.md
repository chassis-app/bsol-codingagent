---
name: qa-runner
description: Run comprehensive post-coding test execution and reporting for an existing codebase, defaulting to Claude Code as the runner. Use when asked to run all tests, perform a QA pass, validate before merge, do smoke/regression checks, or verify changes after coding.
---

# QA Runner

## Overview

Use this skill after implementation work to execute the project's full automated test surface.
Default to Claude Code for command discovery and execution, then report failures with rerun commands.

## Workflow

1. Preflight
- Confirm repository path and run from repo root.
- Confirm Claude Code is available (`$HOME/.local/bin/claude` or `claude` in `PATH`).
- Confirm dependencies are already installed.

2. Start durable session
- Run: `bash scripts/qa_session_with_claude.sh start --repo <repo-path>`.
- Capture `RUN_ID` from the output.
- Keep source unchanged during QA run (read/execute only).
- Let Claude choose stack-appropriate "all tests" commands (unit/integration/e2e where present).

3. Monitor and recover
- Poll status: `bash scripts/qa_session_with_claude.sh status --run-id <RUN_ID>`.
- Stream logs: `bash scripts/qa_session_with_claude.sh tail --run-id <RUN_ID>`.
- If an awaiter/sub-agent dies mid-run, reattach using the same `RUN_ID` and continue polling.
- If status becomes `orphaned`, restart safely from stored metadata:
  `bash scripts/qa_session_with_claude.sh restart --run-id <RUN_ID>`.

4. Return QA report
- List commands executed in order.
- List pass/fail per command.
- For each failure include test name/path and primary error.
- Provide exact rerun command(s).

5. Escalate blockers
- If tests cannot run, report blocker and prerequisite immediately (missing toolchain, env vars, services, credentials).
- If only partial suite ran, list what was skipped and why.

## Resources

- `scripts/run_all_tests_with_claude.sh`
  - Claude-driven all-tests runner with deterministic QA prompt.
- `scripts/qa_session_with_claude.sh`
  - Detached session manager with `start/status/tail/list/stop`, heartbeat checks, and persisted logs.
- `references/report-template.md`
  - Canonical summary shape for final reporting.
