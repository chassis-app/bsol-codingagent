#!/usr/bin/env bash
set -u

usage() {
  cat <<'USAGE'
Usage:
  run_all_tests_with_claude.sh [--repo <path>] [--extra "<text>"] [--dry-run]

Runs a Claude Code-driven QA pass that discovers and executes the project's full automated test suite.

Options:
  --repo <path>     Repository root to test (default: current directory)
  --extra "<text>"  Extra instructions appended to the Claude prompt
  --dry-run         Print prompt and command without invoking Claude
  -h, --help        Show this message

Environment:
  CLAUDE_CODE_BIN   Override Claude CLI binary path
                    Default: ~/.local/bin/claude when present, otherwise claude
USAGE
}

repo_path="."
extra_prompt=""
dry_run=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --repo)
      if [[ $# -lt 2 ]]; then
        echo "ERROR: --repo requires a path argument." >&2
        exit 2
      fi
      repo_path="$2"
      shift 2
      ;;
    --extra)
      if [[ $# -lt 2 ]]; then
        echo "ERROR: --extra requires a text argument." >&2
        exit 2
      fi
      extra_prompt="$2"
      shift 2
      ;;
    --dry-run)
      dry_run=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "ERROR: Unknown argument: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

if [[ -n "${CLAUDE_CODE_BIN:-}" ]]; then
  claude_bin="${CLAUDE_CODE_BIN}"
elif [[ -x "${HOME}/.local/bin/claude" ]]; then
  claude_bin="${HOME}/.local/bin/claude"
else
  claude_bin="claude"
fi

if [[ "$claude_bin" == */* ]]; then
  if [[ ! -x "$claude_bin" ]]; then
    echo "ERROR: Claude Code executable not found: ${claude_bin}" >&2
    exit 1
  fi
else
  if ! command -v "$claude_bin" >/dev/null 2>&1; then
    echo "ERROR: Claude Code executable not found in PATH: ${claude_bin}" >&2
    exit 1
  fi
fi

if ! abs_repo_path="$(cd "$repo_path" 2>/dev/null && pwd -P)"; then
  echo "ERROR: Repository path not accessible: ${repo_path}" >&2
  exit 1
fi

if [[ ! -d "${abs_repo_path}/.git" ]]; then
  echo "WARNING: ${abs_repo_path} does not look like a git repository root (.git missing)." >&2
  echo "WARNING: Proceeding anyway." >&2
fi

prompt=$(cat <<EOF
Act as a strict QA runner for this repository: ${abs_repo_path}

Goal:
- Run the project's full automated test surface after coding changes.
- Prioritize comprehensive test coverage (unit + integration + e2e where available).
- Keep this run read/execute only. Do not modify source files, configs, lockfiles, or tests.

Execution rules:
1) Detect the project's stack and package manager, then select the canonical "all tests" commands.
2) Prefer non-watch, CI-safe commands.
3) If multiple suites exist, run all major suites and continue gathering results when reasonable.
4) If a command fails due to missing dependency/tooling, report the blocker and stop only when no further meaningful suite can run.

Output format:
1. SUMMARY: overall PASS/FAIL
2. COMMANDS: exact commands executed in order
3. RESULTS: pass/fail per command
4. FAILURES: failing test names/files and primary error cause
5. RERUN: exact rerun command(s) for each failed suite
6. BLOCKERS: missing prerequisites or environment requirements
EOF
)

if [[ -n "$extra_prompt" ]]; then
  prompt+=$'\n'
  prompt+=$'\n'
  prompt+="Additional operator instructions:"
  prompt+=$'\n'
  prompt+="${extra_prompt}"
fi

echo "QA runner repo: ${abs_repo_path}"
echo "Claude binary: ${claude_bin}"

if [[ $dry_run -eq 1 ]]; then
  echo
  echo "----- Claude Command -----"
  printf '%q ' "$claude_bin" -p "$prompt"
  echo
  echo "----- Prompt -----"
  printf '%s\n' "$prompt"
  exit 0
fi

cd "$abs_repo_path" || exit 1

output="$("$claude_bin" -p "$prompt" 2>&1)"
status=$?

printf '%s\n' "$output"
exit $status
