#!/usr/bin/env bash
set -u

usage() {
  cat <<'USAGE'
Usage:
  qa_session_with_claude.sh <command> [options]

Commands:
  start    Start detached QA run and print RUN_ID
  status   Show run status and health
  tail     Tail run log
  list     List known runs
  stop     Stop a running session
  restart  Restart a run from stored metadata

Start options:
  --repo <path>      Repository root (default: current directory)
  --run-id <id>      Optional run id (default: timestamp-random)
  --extra "<text>"   Extra instructions appended to Claude prompt

Status options:
  --run-id <id>           Required run id
  --stale-seconds <secs>  Heartbeat stale threshold (default: 90)

Tail options:
  --run-id <id>      Required run id
  --lines <n>        Number of lines (default: 120)

Stop options:
  --run-id <id>      Required run id

Restart options:
  --run-id <id>          Required previous run id
  --new-run-id <id>      Optional replacement run id

Environment:
  QA_RUNNER_STATE_DIR     State directory (default: /tmp/qa-runner-sessions)
  QA_RUNNER_RUNNER_SCRIPT Override runner script path
                          (default: scripts/run_all_tests_with_claude.sh)
USAGE
}

now_utc() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

state_dir="${QA_RUNNER_STATE_DIR:-/tmp/qa-runner-sessions}"
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
default_runner="${script_dir}/run_all_tests_with_claude.sh"
runner_script="${QA_RUNNER_RUNNER_SCRIPT:-$default_runner}"

ensure_state_dir() {
  mkdir -p "$state_dir"
}

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

require_run_dir() {
  local run_id="$1"
  local run_dir="${state_dir}/${run_id}"
  [[ -d "$run_dir" ]] || fail "Run not found: ${run_id}"
  printf '%s\n' "$run_dir"
}

parse_start() {
  local repo="."
  local run_id=""
  local extra=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --repo)
        [[ $# -ge 2 ]] || fail "--repo requires a path argument"
        repo="$2"
        shift 2
        ;;
      --run-id)
        [[ $# -ge 2 ]] || fail "--run-id requires an id argument"
        run_id="$2"
        shift 2
        ;;
      --extra)
        [[ $# -ge 2 ]] || fail "--extra requires a text argument"
        extra="$2"
        shift 2
        ;;
      *)
        fail "Unknown start option: $1"
        ;;
    esac
  done

  local abs_repo
  abs_repo="$(cd "$repo" 2>/dev/null && pwd -P)" || fail "Repository path not accessible: ${repo}"
  [[ -x "$runner_script" ]] || fail "Runner script not executable: ${runner_script}"

  if [[ -z "$run_id" ]]; then
    run_id="$(date -u +%Y%m%d-%H%M%S)-$RANDOM"
  fi
  [[ "$run_id" =~ ^[A-Za-z0-9._-]+$ ]] || fail "Invalid run id: ${run_id}"

  local run_dir="${state_dir}/${run_id}"
  [[ ! -e "$run_dir" ]] || fail "Run id already exists: ${run_id}"
  mkdir -p "$run_dir"

  local worker_file="${run_dir}/worker.sh"
  local pid_file="${run_dir}/pid"
  local status_file="${run_dir}/status"
  local started_file="${run_dir}/started_at"
  local finished_file="${run_dir}/finished_at"
  local heartbeat_file="${run_dir}/heartbeat_at"
  local exit_file="${run_dir}/exit_code"
  local log_file="${run_dir}/run.log"
  local repo_file="${run_dir}/repo_path"
  local extra_file="${run_dir}/extra_prompt"
  local runner_file="${run_dir}/runner_script"

  printf '%s\n' "$abs_repo" > "$repo_file"
  printf '%s\n' "$extra" > "$extra_file"
  printf '%s\n' "$runner_script" > "$runner_file"
  printf '%s\n' "starting" > "$status_file"
  printf '[%s] Session created\n' "$(now_utc)" > "$log_file"
  printf '[%s] Repo: %s\n' "$(now_utc)" "$abs_repo" >> "$log_file"
  printf '[%s] Runner: %s\n' "$(now_utc)" "$runner_script" >> "$log_file"

  {
    echo '#!/usr/bin/env bash'
    echo 'set -u'
    printf 'runner_script=%q\n' "$runner_script"
    printf 'repo_path=%q\n' "$abs_repo"
    printf 'extra_prompt=%q\n' "$extra"
    printf 'status_file=%q\n' "$status_file"
    printf 'started_file=%q\n' "$started_file"
    printf 'finished_file=%q\n' "$finished_file"
    printf 'heartbeat_file=%q\n' "$heartbeat_file"
    printf 'exit_file=%q\n' "$exit_file"
    printf 'log_file=%q\n' "$log_file"
    cat <<'EOF'
now_utc() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

printf '%s\n' "running" > "$status_file"
now_utc > "$started_file"
now_utc > "$heartbeat_file"
printf '[%s] Started detached run\n' "$(now_utc)" >> "$log_file"

heartbeat_loop() {
  while true; do
    now_utc > "$heartbeat_file"
    sleep 5
  done
}

heartbeat_loop &
hb_pid=$!

if [[ -n "$extra_prompt" ]]; then
  "$runner_script" --repo "$repo_path" --extra "$extra_prompt" >>"$log_file" 2>&1
else
  "$runner_script" --repo "$repo_path" >>"$log_file" 2>&1
fi
exit_code=$?

kill "$hb_pid" 2>/dev/null || true
wait "$hb_pid" 2>/dev/null || true
now_utc > "$heartbeat_file"
printf '%s\n' "$exit_code" > "$exit_file"
now_utc > "$finished_file"
if [[ $exit_code -eq 0 ]]; then
  printf '%s\n' "success" > "$status_file"
  printf '[%s] Completed: success\n' "$(now_utc)" >> "$log_file"
else
  printf '%s\n' "failed" > "$status_file"
  printf '[%s] Completed: failed (exit=%s)\n' "$(now_utc)" "$exit_code" >> "$log_file"
fi
exit "$exit_code"
EOF
  } > "$worker_file"

  chmod +x "$worker_file"

  nohup "$worker_file" >/dev/null 2>&1 &
  local pid=$!
  printf '%s\n' "$pid" > "$pid_file"

  echo "RUN_ID=${run_id}"
  echo "RUN_DIR=${run_dir}"
  echo "PID=${pid}"
  echo "LOG=${log_file}"
}

parse_status() {
  local run_id=""
  local stale_seconds=90

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --run-id)
        [[ $# -ge 2 ]] || fail "--run-id requires an id argument"
        run_id="$2"
        shift 2
        ;;
      --stale-seconds)
        [[ $# -ge 2 ]] || fail "--stale-seconds requires a number"
        stale_seconds="$2"
        shift 2
        ;;
      *)
        fail "Unknown status option: $1"
        ;;
    esac
  done

  [[ -n "$run_id" ]] || fail "--run-id is required"
  local run_dir
  run_dir="$(require_run_dir "$run_id")"

  local pid_file="${run_dir}/pid"
  local status_file="${run_dir}/status"
  local heartbeat_file="${run_dir}/heartbeat_at"
  local exit_file="${run_dir}/exit_code"
  local log_file="${run_dir}/run.log"
  local repo_file="${run_dir}/repo_path"

  local pid=""
  local status="unknown"
  local repo_path=""
  local exit_code=""
  local pid_alive=0
  local heartbeat_age=""

  [[ -f "$pid_file" ]] && pid="$(cat "$pid_file")"
  [[ -f "$status_file" ]] && status="$(cat "$status_file")"
  [[ -f "$repo_file" ]] && repo_path="$(cat "$repo_file")"
  [[ -f "$exit_file" ]] && exit_code="$(cat "$exit_file")"

  if [[ -n "$pid" ]] && kill -0 "$pid" >/dev/null 2>&1; then
    pid_alive=1
  fi

  if [[ -f "$heartbeat_file" ]]; then
    local hb epoch now
    hb="$(cat "$heartbeat_file")"
    epoch="$(date -u -d "$hb" +%s 2>/dev/null || true)"
    now="$(date -u +%s)"
    if [[ -n "$epoch" ]]; then
      heartbeat_age="$((now - epoch))"
    fi
  fi

  local health="$status"
  if [[ "$status" == "running" || "$status" == "starting" ]]; then
    if [[ $pid_alive -eq 0 ]]; then
      health="orphaned"
      status="orphaned"
      printf '%s\n' "$status" > "$status_file"
    elif [[ -n "$heartbeat_age" && "$heartbeat_age" -gt "$stale_seconds" ]]; then
      health="running-stale"
    else
      health="running-healthy"
    fi
  fi

  echo "RUN_ID=${run_id}"
  echo "REPO=${repo_path}"
  echo "STATUS=${status}"
  echo "HEALTH=${health}"
  echo "PID=${pid}"
  echo "PID_ALIVE=${pid_alive}"
  echo "HEARTBEAT_AGE_SECONDS=${heartbeat_age}"
  echo "EXIT_CODE=${exit_code}"
  echo "LOG=${log_file}"
  if [[ "$health" == "orphaned" ]]; then
    echo "RECOVERY=Run: qa_session_with_claude.sh restart --run-id ${run_id}"
  fi
}

parse_tail() {
  local run_id=""
  local lines=120

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --run-id)
        [[ $# -ge 2 ]] || fail "--run-id requires an id argument"
        run_id="$2"
        shift 2
        ;;
      --lines)
        [[ $# -ge 2 ]] || fail "--lines requires a number"
        lines="$2"
        shift 2
        ;;
      *)
        fail "Unknown tail option: $1"
        ;;
    esac
  done

  [[ -n "$run_id" ]] || fail "--run-id is required"
  local run_dir
  run_dir="$(require_run_dir "$run_id")"
  local log_file="${run_dir}/run.log"
  [[ -f "$log_file" ]] || fail "No log file found for run: ${run_id}"
  tail -n "$lines" "$log_file"
}

list_runs() {
  ensure_state_dir
  local run_id
  local run_dir
  local status
  local repo
  local started

  echo "RUN_ID STATUS STARTED_AT REPO"
  for run_id in $(ls -1 "$state_dir" 2>/dev/null | sort -r); do
    run_dir="${state_dir}/${run_id}"
    [[ -d "$run_dir" ]] || continue
    status="$(cat "${run_dir}/status" 2>/dev/null || echo "unknown")"
    started="$(cat "${run_dir}/started_at" 2>/dev/null || echo "-")"
    repo="$(cat "${run_dir}/repo_path" 2>/dev/null || echo "-")"
    echo "${run_id} ${status} ${started} ${repo}"
  done
}

parse_stop() {
  local run_id=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --run-id)
        [[ $# -ge 2 ]] || fail "--run-id requires an id argument"
        run_id="$2"
        shift 2
        ;;
      *)
        fail "Unknown stop option: $1"
        ;;
    esac
  done
  [[ -n "$run_id" ]] || fail "--run-id is required"
  local run_dir
  run_dir="$(require_run_dir "$run_id")"
  local pid_file="${run_dir}/pid"
  local status_file="${run_dir}/status"
  local finished_file="${run_dir}/finished_at"
  local log_file="${run_dir}/run.log"

  [[ -f "$pid_file" ]] || fail "No PID file for run: ${run_id}"
  local pid
  pid="$(cat "$pid_file")"
  if kill -0 "$pid" >/dev/null 2>&1; then
    kill "$pid" >/dev/null 2>&1 || true
    sleep 1
    if kill -0 "$pid" >/dev/null 2>&1; then
      kill -9 "$pid" >/dev/null 2>&1 || true
    fi
    printf '%s\n' "stopped" > "$status_file"
    now_utc > "$finished_file"
    printf '[%s] Stopped by operator\n' "$(now_utc)" >> "$log_file"
    echo "Stopped run: ${run_id}"
  else
    echo "Run is not active: ${run_id}"
  fi
}

parse_restart() {
  local run_id=""
  local new_run_id=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --run-id)
        [[ $# -ge 2 ]] || fail "--run-id requires an id argument"
        run_id="$2"
        shift 2
        ;;
      --new-run-id)
        [[ $# -ge 2 ]] || fail "--new-run-id requires an id argument"
        new_run_id="$2"
        shift 2
        ;;
      *)
        fail "Unknown restart option: $1"
        ;;
    esac
  done

  [[ -n "$run_id" ]] || fail "--run-id is required"
  local run_dir
  run_dir="$(require_run_dir "$run_id")"

  local repo_path
  local extra_prompt
  repo_path="$(cat "${run_dir}/repo_path" 2>/dev/null || true)"
  extra_prompt="$(cat "${run_dir}/extra_prompt" 2>/dev/null || true)"
  [[ -n "$repo_path" ]] || fail "Cannot restart; missing repo metadata on run: ${run_id}"

  if [[ -n "$new_run_id" ]]; then
    if [[ -n "$extra_prompt" ]]; then
      parse_start --repo "$repo_path" --run-id "$new_run_id" --extra "$extra_prompt"
    else
      parse_start --repo "$repo_path" --run-id "$new_run_id"
    fi
  else
    if [[ -n "$extra_prompt" ]]; then
      parse_start --repo "$repo_path" --extra "$extra_prompt"
    else
      parse_start --repo "$repo_path"
    fi
  fi
}

main() {
  [[ $# -ge 1 ]] || {
    usage
    exit 2
  }

  ensure_state_dir
  local cmd="$1"
  shift

  case "$cmd" in
    start)
      parse_start "$@"
      ;;
    status)
      parse_status "$@"
      ;;
    tail)
      parse_tail "$@"
      ;;
    list)
      list_runs
      ;;
    stop)
      parse_stop "$@"
      ;;
    restart)
      parse_restart "$@"
      ;;
    -h|--help|help)
      usage
      ;;
    *)
      fail "Unknown command: ${cmd}"
      ;;
  esac
}

main "$@"
