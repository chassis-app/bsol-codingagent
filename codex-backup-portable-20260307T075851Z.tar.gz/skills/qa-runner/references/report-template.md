# QA Runner Report Template

Use this exact section order when returning results:

1. `SUMMARY`
- Overall `PASS` or `FAIL`
- One-line reason
- `RUN_ID` used for this session

2. `COMMANDS`
- Ordered list of exact commands executed

3. `RESULTS`
- Per-command status and key metric (tests passed/failed/skipped if available)

4. `FAILURES`
- Failing test case(s) with:
  - test name
  - file path
  - primary error message

5. `RERUN`
- Exact rerun command per failed suite

6. `BLOCKERS`
- Missing prerequisites, env vars, services, or credentials
- If none, write `None`
