# Test Matrix Template

## Feature

- Name:
- Owner:
- Requirements Source:

## Assumptions

- [ ]

## Coverage Matrix

| Test ID | Behavior | Scope | Priority | Preconditions | Assertions |
| --- | --- | --- | --- | --- | --- |
| FEAT-001 |  | Unit | P0 |  |  |
| FEAT-002 |  | Integration | P0 |  |  |
| FEAT-003 |  | E2E | P1 |  |  |

## Regression Watchlist

- [ ] Data contracts
- [ ] Error contract stability
- [ ] Backward compatibility
