# TDD Without Existing Code

## Goal

Create executable failing tests from product behavior before implementation exists.

## Steps

1. Convert acceptance criteria into testable statements.
2. Define external interfaces the tests need (API routes, service methods, UI actions).
3. Write tests that assert observable behavior only.
4. Add minimal scaffolding for imports, fixtures, and test bootstrapping.
5. Mark unknowns with `TODO(TDD-ASSUMPTION)` and continue.

## Assumption Pattern

Use this exact template for each assumption:

- `ASSUMPTION`: short statement
- `IMPACT`: what may need to change later
- `TEST_IDS`: affected tests

## Minimum Coverage Before Handoff

- Happy path
- Validation and error path
- Boundary condition
- Authorization or permissions path (if relevant)
- One end-to-end critical user journey
