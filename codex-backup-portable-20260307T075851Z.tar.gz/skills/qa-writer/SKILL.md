---
name: qa-writer
description: Write and maintain behavior-first unit, integration, and end-to-end tests. Use when users ask to write tests, add missing coverage, create a test plan or matrix, convert requirements into TDD suites before implementation exists, or improve regression coverage in an existing codebase.
---

# QA Writer

## Overview

Use this skill to convert requirements into executable tests across unit, integration, and e2e levels.
Default to TDD: define expected behavior first, write failing tests, then evolve tests as implementation appears.

## Workflow

1. Capture inputs and constraints.
- Extract acceptance criteria, non-functional constraints, target stack, and test framework.
- If a requirement is ambiguous, state assumptions explicitly and proceed with the safest behavior.

2. Build the behavior contract first.
- Define observable behavior, not internal implementation.
- Name each behavior with a stable test ID (for example, `AUTH-LOGIN-001`).
- Include success cases, failure cases, boundary conditions, and error handling.

3. Partition behaviors by test scope.
- Unit: pure logic, edge cases, deterministic outcomes.
- Integration: boundaries between modules, databases, queues, APIs, adapters.
- E2E: user-critical flows, navigation, permissions, and real environment wiring.

4. Write tests for red phase when code is absent.
- Create failing tests against expected public interfaces.
- Define minimal interface assumptions in test setup when needed.
- Avoid inventing private internals. Test through contract-level seams.
- Mark provisional assumptions with a clear `TODO(TDD-ASSUMPTION)` comment.

5. Implement robust assertions.
- Assert outcomes and side effects.
- Assert negative behavior and error messages/status codes.
- Keep one primary behavior per test.

6. Add fixtures, factories, and doubles deliberately.
- Use builders/factories to keep tests readable.
- Mock only boundaries, not the unit under test.
- Prefer stable test data over random input unless property testing is requested.

7. Output a complete test artifact list.
- Provide files created/updated.
- Provide run commands.
- Provide unresolved assumptions and risk gaps.

## TDD-First Rules

- Start from acceptance criteria when code does not exist.
- Write tests that can fail for the right reason.
- Keep expected interface small and explicit.
- Do not block on missing implementation; scaffold test harness and fixtures.
- When implementation arrives, update only assumptions that changed.

## Framework Detection and Conventions

- Prefer existing project tools and naming conventions.
- JavaScript/TypeScript: detect `vitest`, `jest`, `playwright`, `cypress` from `package.json`.
- Python: detect `pytest` and existing fixture structure.
- Backend integration: reuse project test containers, DB setup, and API clients when available.
- E2E: prioritize deterministic selectors (`data-testid`) and stable waits.

## Deliverable Format

When returning work, include these sections in this order:

1. Assumptions
2. Test Plan (unit/integration/e2e mapping)
3. Test Files and Code
4. Run Commands
5. Open Risks or Follow-up Tests

## Resources

- `scripts/create_test_plan.py`
  - Generate a baseline test plan markdown from acceptance criteria.
- `references/tdd-no-code-workflow.md`
  - TDD workflow for greenfield situations with no implementation code.
- `references/test-matrix-template.md`
  - Reusable checklist for unit/integration/e2e coverage.
