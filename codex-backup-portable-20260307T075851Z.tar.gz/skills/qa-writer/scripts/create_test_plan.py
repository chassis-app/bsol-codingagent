#!/usr/bin/env python3
"""Generate a baseline TDD test plan markdown from acceptance criteria."""

from __future__ import annotations

import argparse
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate a unit/integration/e2e test plan from acceptance criteria."
    )
    parser.add_argument("--title", required=True, help="Feature title")
    parser.add_argument(
        "--criterion",
        action="append",
        default=[],
        help="Acceptance criterion (repeatable)",
    )
    parser.add_argument(
        "--criteria-file",
        help="Path to newline-delimited acceptance criteria",
    )
    parser.add_argument(
        "--id-prefix",
        default="TEST",
        help="Prefix for test IDs (default: TEST)",
    )
    parser.add_argument(
        "--output",
        default="TEST_PLAN.md",
        help="Output markdown path (default: TEST_PLAN.md)",
    )
    return parser.parse_args()


def load_criteria(args: argparse.Namespace) -> list[str]:
    criteria = [c.strip() for c in args.criterion if c.strip()]
    if args.criteria_file:
        lines = Path(args.criteria_file).read_text(encoding="utf-8").splitlines()
        criteria.extend(line.strip() for line in lines if line.strip())
    deduped: list[str] = []
    seen = set()
    for criterion in criteria:
        if criterion not in seen:
            deduped.append(criterion)
            seen.add(criterion)
    return deduped


def build_matrix(id_prefix: str, criteria: list[str]) -> str:
    rows = ["| Test ID | Behavior | Scope | Priority | Preconditions | Assertions |"]
    rows.append("| --- | --- | --- | --- | --- | --- |")

    index = 1
    for criterion in criteria:
        test_id = f"{id_prefix}-{index:03d}"
        rows.append(f"| {test_id} | {criterion} | Unit | P0 | Define fixture/setup | Assert core behavior |")
        index += 1
        test_id = f"{id_prefix}-{index:03d}"
        rows.append(f"| {test_id} | {criterion} | Integration | P1 | Wire real boundary + stub externals | Assert contract + side effects |")
        index += 1
        test_id = f"{id_prefix}-{index:03d}"
        rows.append(f"| {test_id} | {criterion} | E2E | P1 | App seeded and running | Assert user-visible outcome |")
        index += 1

    return "\n".join(rows)


def render_plan(title: str, id_prefix: str, criteria: list[str]) -> str:
    criteria_lines = "\n".join(f"- {c}" for c in criteria)
    matrix = build_matrix(id_prefix, criteria)
    return f"""# Test Plan: {title}

## Acceptance Criteria
{criteria_lines}

## Assumptions
- TODO(TDD-ASSUMPTION): Add interface assumptions required to compile/run tests.

## Coverage Matrix
{matrix}

## Open Risks
- TODO: Add risks discovered during test authoring.
"""


def main() -> int:
    args = parse_args()
    criteria = load_criteria(args)
    if not criteria:
        raise SystemExit("Provide at least one criterion via --criterion or --criteria-file.")

    plan = render_plan(args.title.strip(), args.id_prefix.strip(), criteria)
    output = Path(args.output)
    output.write_text(plan, encoding="utf-8")
    print(f"Wrote {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
