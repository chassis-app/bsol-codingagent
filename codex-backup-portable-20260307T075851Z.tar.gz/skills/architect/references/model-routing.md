# GLM Routing Notes

## Recommended defaults

- Provider id: `zai`
- Provider SDK: `@ai-sdk/openai-compatible`
- Provider API: `https://open.bigmodel.cn/api/paas/v4`
- Model reference passed to OpenCode: `zai-coding-plan/glm-5`

## Common alternatives

- If your endpoint is OpenAI-compatible but not Z.AI, keep the same SDK (`@ai-sdk/openai-compatible`) and change:
  - `provider-id`
  - `provider-api`
  - `model-id`
- If your GLM route is through an existing OpenCode provider, keep that provider id and only change the model id.

## Verification commands

```bash
opencode --version
opencode run --help
opencode debug config
```

## Quick dry run

```bash
bash scripts/run_opencode_architect.sh "Sanity-check architect routing"
```

## Failure handling

- Ask upfront before running OpenCode:
  - `Do you want me to run this out of sandbox now to avoid sandbox failures?`
- If approved, run out of sandbox directly (do not run a sandbox attempt first).
- If it still fails out of sandbox, ask the user to fix their local OpenCode/GLM setup.
