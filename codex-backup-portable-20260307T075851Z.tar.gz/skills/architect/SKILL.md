---
name: opencode-glm-architect
description: Run OpenCode with a GLM model in an architect-focused agent mode. Use when users ask to route architecture/planning work through OpenCode (especially zai-coding-plan/glm-5) and launch architect sessions with consistent prompts and model routing.
---

# Opencode Glm Architect

## Overview

Use this skill to run an `architect` agent on GLM reliably and produce an implementation-ready plan.
Assume OpenCode is already installed and GLM routing is already configured in OpenCode.
Prefer the bundled run script for consistent agent/model routing across sessions.
Do not modify OpenCode config as part of this skill unless the user explicitly asks for configuration changes.

## Mandatory Planning Standard

For planning requests, require the architect output to include a strict Markdown artifact named `task-execution-plan.md`.
If the repository has a preferred planning location, place it there; otherwise default to repository root.

The generated plan must include all sections below. Do not accept a plan that skips any section.

1. `Task Goal`
- Clear objective, success criteria, and explicit out-of-scope items.

2. `Scenarios`
- Enumerate all user/system scenarios for the page or feature, including happy path, edge cases, empty states, loading states, error states, permission/auth variations, and recovery paths.

3. `UI/UX Direction`
- State UX intent, interaction principles, accessibility expectations, validation behavior, content/microcopy expectations, and responsive behavior notes.

4. `Implementation Breakdown`
- Break work into concrete subtasks and sub-sections.
- For each subtask include detailed specification, touched files/modules, expected inputs/outputs, and acceptance criteria.

5. `Function and Feature Matrix per Subtask`
- For each subtask, explicitly list all functions/features to implement.
- Include function purpose, parameters/contracts, return behavior, error behavior, and dependencies.

6. `Form/Schema Coverage`
- If the task touches forms or DB schemas, read schema definitions first and include all relevant fields in the plan.
- For each field include name, type, required/optional, validation rules, defaults, transformations, storage mapping, and API exposure.
- No partial field lists are allowed when a full schema/form is in scope.

7. `Interaction Response Spec`
- For each interactive element (buttons, menus, forms, tables, pagination, filters, modals, keyboard shortcuts, async actions), define expected response for success, failure, disabled state, loading state, retry, and permission denial where applicable.

8. `Testing Plan (Mandatory)`
- Unit tests per subtask/function group.
- Integration tests for cross-module/database/API flows.
- End-to-end tests covering critical user journeys and error journeys.
- Include fixtures, test data assumptions, and pass/fail criteria.

## Execution Workflow

1. Before running OpenCode, explicitly ask for out-of-sandbox execution approval:
   - `Do you want me to run this out of sandbox now to avoid sandbox failures?`
2. If approved, run an architect session out of sandbox:
   - Interactive: `bash scripts/run_opencode_architect.sh --interactive`
   - One-shot: `bash scripts/run_opencode_architect.sh "Design a multi-tenant billing architecture"`
3. For planning tasks, prepend or include this enforcement instruction in the architect prompt:
   - `Produce task-execution-plan.md and include all mandatory sections from the skill without omission. Read relevant schema/form definitions and include all relevant fields. Include unit, integration, and end-to-end test plans tied to subtasks.`
4. Do not run a sandbox attempt first for OpenCode commands.
5. If it still fails after out-of-sandbox execution, stop and explicitly ask the user to fix their local OpenCode/GLM setup themselves.
6. Verify effective config when behavior is unexpected:
   - Run `opencode debug config`

## Scripts

- `scripts/run_opencode_architect.sh`
  - Runs OpenCode with `--agent architect --model zai-coding-plan/glm-5` by default
  - Honors `OPENCODE_ARCHITECT_AGENT` and `OPENCODE_ARCHITECT_MODEL`
- `scripts/configure_opencode_glm_architect.py`
  - Legacy helper for explicit config-edit requests only
  - Do not run by default for this skill

## Model Routing

If the user needs a non-default GLM route, switch only the routing fields instead of rewriting the workflow:

- `--provider-id`
- `--provider-api`
- `--model-id`

For routing details and dry-run patterns, read `references/model-routing.md`.
