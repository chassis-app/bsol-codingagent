#!/usr/bin/env bash
set -euo pipefail

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  cat <<'EOF'
Usage:
  run_opencode_architect.sh [message...]
  run_opencode_architect.sh --interactive

Environment:
  OPENCODE_ARCHITECT_AGENT   Agent name (default: architect)
  OPENCODE_ARCHITECT_MODEL   Model reference (default: zai-coding-plan/glm-5)
EOF
  exit 0
fi

agent="${OPENCODE_ARCHITECT_AGENT:-architect}"
model="${OPENCODE_ARCHITECT_MODEL:-zai-coding-plan/glm-5}"

if [[ "${1:-}" == "--interactive" || "$#" -eq 0 ]]; then
  exec opencode --agent "$agent" --model "$model"
fi

exec opencode run --agent "$agent" --model "$model" "$@"
