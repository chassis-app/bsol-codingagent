#!/usr/bin/env python3
"""Configure OpenCode provider + architect agent for GLM usage."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any


DEFAULT_PROMPT = """You are a principal software architect.
Prioritize system boundaries, interfaces, reliability, security, and migration safety.
Before coding, produce a concise architecture plan with tradeoffs, risks, and rollout steps.
When details are unknown, state assumptions explicitly and propose validation steps."""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Configure OpenCode for GLM architect workflows."
    )
    parser.add_argument(
        "--config-path",
        default="~/.config/opencode/opencode.json",
        help="Path to opencode.json (default: ~/.config/opencode/opencode.json)",
    )
    parser.add_argument(
        "--provider-id",
        default="zai-coding-plan",
        help="Provider id used by OpenCode (default: zai-coding-plan)",
    )
    parser.add_argument(
        "--provider-name",
        default="Z.AI GLM",
        help="Provider display name (default: Z.AI GLM)",
    )
    parser.add_argument(
        "--provider-npm",
        default="@ai-sdk/openai-compatible",
        help="Provider SDK package (default: @ai-sdk/openai-compatible)",
    )
    parser.add_argument(
        "--provider-api",
        default="https://open.bigmodel.cn/api/paas/v4",
        help="Provider base URL",
    )
    parser.add_argument(
        "--api-key",
        default="",
        help="Provider API key. If omitted, read from GLM_API_KEY/ZAI_API_KEY/ZHIPUAI_API_KEY.",
    )
    parser.add_argument(
        "--model-id",
        default="glm-5",
        help="GLM model id within the provider (default route resolves to zai-coding-plan/glm-5)",
    )
    parser.add_argument(
        "--agent-name",
        default="architect",
        help="Agent name to create/update (default: architect)",
    )
    parser.add_argument(
        "--agent-description",
        default="Use for architecture design, system planning, and high-level technical decisions.",
        help="Agent description for OpenCode",
    )
    parser.add_argument(
        "--agent-prompt",
        default=DEFAULT_PROMPT,
        help="System prompt for the architect agent",
    )
    parser.add_argument(
        "--set-defaults",
        action="store_true",
        help="Also set top-level model/default_agent to this provider+agent",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print resulting config to stdout without writing file",
    )
    return parser.parse_args()


def load_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"$schema": "https://opencode.ai/config.json"}
    raw = path.read_text(encoding="utf-8").strip()
    if not raw:
        return {"$schema": "https://opencode.ai/config.json"}
    return json.loads(raw)


def resolve_api_key(cli_value: str) -> str:
    if cli_value:
        return cli_value
    for name in ("GLM_API_KEY", "ZAI_API_KEY", "ZHIPUAI_API_KEY"):
        value = os.environ.get(name, "").strip()
        if value:
            return value
    raise SystemExit(
        "Missing API key. Pass --api-key or set GLM_API_KEY/ZAI_API_KEY/ZHIPUAI_API_KEY."
    )


def ensure_provider(config: dict[str, Any], args: argparse.Namespace, api_key: str) -> None:
    providers = config.setdefault("provider", {})
    provider = providers.setdefault(args.provider_id, {})
    provider["id"] = args.provider_id
    provider["name"] = args.provider_name
    provider["npm"] = args.provider_npm
    provider["api"] = args.provider_api

    options = provider.setdefault("options", {})
    options["baseURL"] = args.provider_api
    options["apiKey"] = api_key


def ensure_agent(config: dict[str, Any], args: argparse.Namespace, model_ref: str) -> None:
    agents = config.setdefault("agent", {})
    agent = agents.setdefault(args.agent_name, {})
    agent["description"] = args.agent_description
    agent["mode"] = "primary"
    agent["model"] = model_ref
    agent["prompt"] = args.agent_prompt


def main() -> None:
    args = parse_args()
    config_path = Path(os.path.expanduser(args.config_path))
    config = load_config(config_path)
    api_key = resolve_api_key(args.api_key)
    model_ref = f"{args.provider_id}/{args.model_id}"

    ensure_provider(config, args, api_key)
    ensure_agent(config, args, model_ref)

    if args.set_defaults:
        config["model"] = model_ref
        config["default_agent"] = args.agent_name

    rendered = json.dumps(config, indent=2, ensure_ascii=True) + "\n"
    if args.dry_run:
        print(rendered, end="")
        return

    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(rendered, encoding="utf-8")
    print(f"Updated {config_path}")
    print(f"Model: {model_ref}")
    print(f"Agent: {args.agent_name}")


if __name__ == "__main__":
    main()
